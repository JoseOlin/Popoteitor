#include <Arduino.h>
#include <Servo.h>

Servo srv;
int pin_entradaBtn = 3;
int estadoBtn = 0;
int estadoBtn_anterior = 0;
int salida = 0;

void setup() {
  Serial.begin(115200);
  srv.attach(5);
  pinMode(pin_entradaBtn, INPUT);
  srv.write(0);
}

void loop() {
  estadoBtn = digitalRead(pin_entradaBtn);

  if((estadoBtn == HIGH) && (estadoBtn_anterior == LOW)){
    salida = 1 - salida;
    delay(25);
  }
  estadoBtn_anterior = estadoBtn;

  if(salida == 1){
    srv.write(90);
    Serial.println("Servo 90");
  }
  else{
    srv.write(0);
    Serial.println("Servo 0");
  }

}